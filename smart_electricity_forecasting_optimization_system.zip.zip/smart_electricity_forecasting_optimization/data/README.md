Put source datasets in `raw/` and cleaned/generated datasets in `processed/`.
The SQLite database file is created as `smart_electricity.db` in this folder when the app runs.
