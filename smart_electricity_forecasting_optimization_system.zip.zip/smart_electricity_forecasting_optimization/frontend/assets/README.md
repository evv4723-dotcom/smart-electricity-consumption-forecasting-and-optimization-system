Place custom CSS, logos, icons, and project-owned images in this folder.
Do not store generated datasets or the SQLite database here.
