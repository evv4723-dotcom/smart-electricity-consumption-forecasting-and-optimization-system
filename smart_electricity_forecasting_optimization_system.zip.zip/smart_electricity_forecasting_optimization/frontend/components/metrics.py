"""Reusable UI components can be added here."""


def format_kwh(value: float) -> str:
    return f"{value:,.2f} kWh"
