
import streamlit as st
import pandas as pd
import plotly.express as px
from pathlib import Path

st.set_page_config(
    page_title="Smart Electricity Consumption System",
    page_icon="⚡",
    layout="wide"
)

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "processed" / "electricity_data.csv"

st.title("⚡ Smart Electricity Consumption Dashboard")
st.caption("Monitor, analyze, and optimize your electricity consumption.")

# Sidebar navigation links
st.sidebar.title("Navigation")
st.sidebar.page_link("app.py", label="Home", icon="🏠")
st.sidebar.page_link(
    "pages/1_Dashboard.py", label="Dashboard", icon="📊"
)
st.sidebar.page_link(
    "pages/2_Data_Management.py", label="Data Management", icon="📁"
)
st.sidebar.page_link(
    "pages/3_Forecasting.py", label="Forecasting", icon="🔮"
)
st.sidebar.page_link(
    "pages/4_Bill_Estimation.py", label="Bill Estimation", icon="💰"
)
st.sidebar.page_link(
    "pages/5_Optimization.py", label="Optimization", icon="⚡"
)
st.sidebar.page_link(
    "pages/6_Reports.py", label="Reports", icon="📄"
)

if not DATA_PATH.exists():
    st.warning("No electricity data has been uploaded yet.")
    st.info("Open Data Management from the sidebar and upload your CSV.")
    st.stop()

try:
    df = pd.read_csv(DATA_PATH)
    df["timestamp"] = pd.to_datetime(
        df["timestamp"], errors="coerce"
    )
    df["consumption_kwh"] = pd.to_numeric(
        df["consumption_kwh"], errors="coerce"
    )
    df = df.dropna(
        subset=["timestamp", "consumption_kwh"]
    ).sort_values("timestamp")

    if df.empty:
        st.error("Your CSV contains no valid readings.")
        st.stop()

    total = df["consumption_kwh"].sum()
    average = df["consumption_kwh"].mean()
    peak = df["consumption_kwh"].max()
    latest = df.iloc[-1]["consumption_kwh"]

    st.subheader("Consumption Overview")

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total Consumption", f"{total:.2f} kWh")
    c2.metric("Average Reading", f"{average:.2f} kWh")
    c3.metric("Peak Reading", f"{peak:.2f} kWh")
    c4.metric("Latest Reading", f"{latest:.2f} kWh")

    st.subheader("Electricity Consumption Over Time")

    line = px.line(
        df,
        x="timestamp",
        y="consumption_kwh",
        markers=True,
        title="Consumption by Reading",
        labels={
            "timestamp": "Date and Time",
            "consumption_kwh": "Consumption (kWh)"
        }
    )
    st.plotly_chart(line, use_container_width=True)

    st.subheader("Daily Consumption")

    daily = df.copy()
    daily["date"] = daily["timestamp"].dt.date
    daily = daily.groupby(
        "date", as_index=False
    )["consumption_kwh"].sum()

    bar = px.bar(
        daily,
        x="date",
        y="consumption_kwh",
        title="Total Consumption per Day",
        labels={
            "date": "Date",
            "consumption_kwh": "Consumption (kWh)"
        }
    )
    st.plotly_chart(bar, use_container_width=True)

    st.subheader("Recent Electricity Readings")
    st.dataframe(
        df[["timestamp", "consumption_kwh"]].tail(10),
        use_container_width=True,
        hide_index=True
    )

except Exception as exc:
    st.error(f"Unable to display electricity data: {exc}")
