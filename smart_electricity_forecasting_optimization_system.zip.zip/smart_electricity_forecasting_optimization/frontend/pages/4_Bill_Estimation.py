
import streamlit as st
import pandas as pd
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DATA_PATH = ROOT / "data" / "processed" / "electricity_data.csv"

st.title("Electricity Bill Estimation")
st.write("Estimate electricity charges from your consumption data.")

if not DATA_PATH.exists():
    st.warning("Please upload electricity data in Data Management first.")
    st.stop()

df = pd.read_csv(DATA_PATH)
df["consumption_kwh"] = pd.to_numeric(
    df["consumption_kwh"], errors="coerce"
)
df = df.dropna(subset=["consumption_kwh"])

if df.empty:
    st.error("No valid consumption readings found.")
    st.stop()

st.subheader("Bill Settings")

col1, col2 = st.columns(2)

with col1:
    rate = st.number_input(
        "Electricity rate (₹ per kWh)",
        min_value=0.0,
        value=7.0,
        step=0.5
    )

with col2:
    fixed_charge = st.number_input(
        "Fixed charges (₹)",
        min_value=0.0,
        value=100.0,
        step=10.0
    )

st.info(
    "Enter the rate and fixed charges from your electricity bill "
    "for a more realistic estimate."
)

st.subheader("Consumption Summary")

total_kwh = df["consumption_kwh"].sum()
energy_charge = total_kwh * rate
estimated_bill = energy_charge + fixed_charge

col1, col2, col3 = st.columns(3)

col1.metric("Total Consumption", f"{total_kwh:.2f} kWh")
col2.metric("Energy Charges", f"₹{energy_charge:.2f}")
col3.metric("Estimated Bill", f"₹{estimated_bill:.2f}")

st.subheader("Bill Breakdown")

bill_df = pd.DataFrame({
    "Description": ["Energy Charges", "Fixed Charges", "Estimated Total"],
    "Amount (₹)": [energy_charge, fixed_charge, estimated_bill]
})

st.dataframe(bill_df, use_container_width=True, hide_index=True)

st.caption(
    "This is a basic estimate based on the uploaded readings. "
    "It does not include taxes, subsidies, slab rates, or other "
    "utility-specific charges. Make sure the readings cover the "
    "billing period before using the estimate."
)

st.download_button(
    "Download Bill Estimate",
    bill_df.to_csv(index=False).encode("utf-8"),
    file_name="electricity_bill_estimate.csv",
    mime="text/csv"
)
