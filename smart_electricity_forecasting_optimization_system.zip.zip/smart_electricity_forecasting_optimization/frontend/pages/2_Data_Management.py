
import streamlit as st
import pandas as pd
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]

if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from backend.data.preprocessing import validate_readings

st.title("Data Management")
st.write(
    "Upload electricity data with timestamp and consumption_kwh columns."
)

DATA_PATH = ROOT / "data" / "processed" / "electricity_data.csv"
uploaded = st.file_uploader(
    "Choose electricity consumption CSV",
    type=["csv"]
)

if uploaded is not None:
    try:
        raw = pd.read_csv(uploaded)
        cleaned = validate_readings(raw)

        if cleaned.empty:
            st.error("The CSV contains no valid readings.")
        else:
            DATA_PATH.parent.mkdir(parents=True, exist_ok=True)
            cleaned.to_csv(DATA_PATH, index=False)

            st.success(
                f"Successfully saved {len(cleaned)} readings!"
            )
            st.info(
                "Your data is saved. Open Dashboard in the sidebar "
                "to view your consumption."
            )

            st.dataframe(cleaned, use_container_width=True)

            st.download_button(
                "Download cleaned CSV",
                cleaned.to_csv(index=False).encode("utf-8"),
                file_name="cleaned_electricity_data.csv",
                mime="text/csv",
            )

    except Exception as exc:
        st.error(f"Could not process the CSV: {exc}")
