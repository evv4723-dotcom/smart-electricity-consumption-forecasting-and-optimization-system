
import streamlit as st
import pandas as pd
import plotly.express as px
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]

if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from backend.ml.predict import predict_timestamps

DATA_PATH = ROOT / "data" / "processed" / "electricity_data.csv"

st.title("Electricity Consumption Forecasting")
st.write("Predict future electricity consumption using machine learning.")

if not DATA_PATH.exists():
    st.warning("Upload electricity data in Data Management first.")
    st.stop()

df = pd.read_csv(DATA_PATH)
df["timestamp"] = pd.to_datetime(
    df["timestamp"], errors="coerce"
)
df["consumption_kwh"] = pd.to_numeric(
    df["consumption_kwh"], errors="coerce"
)
df = df.dropna(
    subset=["timestamp", "consumption_kwh"]
).sort_values("timestamp")

if df.empty:
    st.error("No valid electricity readings found.")
    st.stop()

st.subheader("Historical Data")
st.metric("Available readings", len(df))
st.write(
    "Latest reading:",
    df["timestamp"].iloc[-1].strftime("%Y-%m-%d %H:%M")
)

st.subheader("Forecast Settings")

horizon = st.selectbox(
    "How many hours ahead do you want to predict?",
    [6, 12, 24, 48],
    index=2
)

if st.button("Generate Forecast", type="primary"):
    try:
        last_timestamp = df["timestamp"].iloc[-1]

        # Assumes the source readings are hourly.
        future_times = pd.date_range(
            start=last_timestamp + pd.Timedelta(hours=1),
            periods=horizon,
            freq="h"
        )

        predictions = predict_timestamps(future_times)

        forecast_df = pd.DataFrame({
            "timestamp": future_times,
            "predicted_kwh": predictions
        })

        st.success("Forecast generated successfully!")

        st.metric(
            "Predicted total consumption",
            f"{forecast_df['predicted_kwh'].sum():.2f} kWh"
        )

        st.metric(
            "Average predicted hourly consumption",
            f"{forecast_df['predicted_kwh'].mean():.2f} kWh"
        )

        fig = px.line(
            forecast_df,
            x="timestamp",
            y="predicted_kwh",
            markers=True,
            title="Predicted Electricity Consumption",
            labels={
                "timestamp": "Future Date and Time",
                "predicted_kwh": "Predicted Consumption (kWh)"
            }
        )

        st.plotly_chart(fig, use_container_width=True)

        st.subheader("Forecast Results")
        st.dataframe(forecast_df, use_container_width=True)

        st.download_button(
            "Download Forecast CSV",
            forecast_df.to_csv(index=False).encode("utf-8"),
            file_name="electricity_forecast.csv",
            mime="text/csv"
        )

        st.caption(
            "These are baseline model estimates, not guaranteed "
            "future consumption. Accuracy depends on the amount "
            "and quality of historical data."
        )

    except FileNotFoundError:
        st.error(
            "The trained model was not found. Run "
            "'py -m backend.ml.train_model' in the project terminal first."
        )
    except Exception as exc:
        st.error(f"Forecast failed: {exc}")
