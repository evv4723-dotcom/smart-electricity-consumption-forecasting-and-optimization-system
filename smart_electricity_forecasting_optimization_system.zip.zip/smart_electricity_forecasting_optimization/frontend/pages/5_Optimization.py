
import streamlit as st
import pandas as pd
import plotly.express as px
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DATA_PATH = ROOT / "data" / "processed" / "electricity_data.csv"

st.title("⚡ Electricity Consumption Optimization")
st.write(
    "Analyze your electricity usage and explore potential savings."
)

if not DATA_PATH.exists():
    st.warning("Please upload electricity data in Data Management first.")
    st.stop()

df = pd.read_csv(DATA_PATH)

df["timestamp"] = pd.to_datetime(
    df["timestamp"], errors="coerce"
)
df["consumption_kwh"] = pd.to_numeric(
    df["consumption_kwh"], errors="coerce"
)

df = df.dropna(
    subset=["timestamp", "consumption_kwh"]
).sort_values("timestamp")

if df.empty:
    st.error("No valid electricity readings were found.")
    st.stop()

st.subheader("Optimization Settings")

col1, col2 = st.columns(2)

with col1:
    rate = st.number_input(
        "Electricity rate (₹ per kWh)",
        min_value=0.0,
        value=7.0,
        step=0.5,
        key="optimization_rate"
    )

with col2:
    target_percent = st.slider(
        "Target consumption reduction (%)",
        min_value=5,
        max_value=50,
        value=10,
        step=5
    )

total_kwh = df["consumption_kwh"].sum()
current_cost = total_kwh * rate
potential_savings = current_cost * target_percent / 100
optimized_cost = current_cost - potential_savings

st.subheader("Consumption Summary")

col1, col2, col3 = st.columns(3)
col1.metric("Total Consumption", f"{total_kwh:.2f} kWh")
col2.metric("Energy Cost", f"₹{current_cost:.2f}")
col3.metric(
    "Potential Savings",
    f"₹{potential_savings:.2f}",
    f"{target_percent}% of energy cost"
)

st.metric(
    "Estimated Cost After Reduction",
    f"₹{optimized_cost:.2f}"
)

st.caption(
    "Potential savings are a what-if estimate based on your selected "
    "reduction target, not a guaranteed saving."
)

st.subheader("Consumption by Hour")

df["hour"] = df["timestamp"].dt.hour

hourly = (
    df.groupby("hour", as_index=False)["consumption_kwh"]
    .mean()
)

hourly.columns = ["Hour", "Average Consumption (kWh)"]

fig = px.bar(
    hourly,
    x="Hour",
    y="Average Consumption (kWh)",
    title="Average Electricity Consumption by Hour",
    labels={"Hour": "Hour of Day (0–23)"}
)

st.plotly_chart(fig, use_container_width=True)

st.subheader("High-Consumption Periods")

average_usage = df["consumption_kwh"].mean()

high_usage = df[
    df["consumption_kwh"] > average_usage
].copy()

if high_usage.empty:
    st.info("No readings above the average were found.")
else:
    high_usage["hour"] = high_usage["timestamp"].dt.strftime("%H:%M")
    st.write(
        f"Average reading: {average_usage:.2f} kWh. "
        "The following readings are above this average."
    )
    st.dataframe(
        high_usage[["timestamp", "hour", "consumption_kwh"]],
        use_container_width=True,
        hide_index=True
    )

st.subheader("Energy-Saving Recommendations")

peak_hour = int(hourly.loc[
    hourly["Average Consumption (kWh)"].idxmax(), "Hour"
])

st.write(
    f"- Your highest average usage occurs around {peak_hour:02d}:00. "
    "Review which appliances are operating during this period."
)
st.write(
    "- Turn off lights, fans, and appliances when they are not needed."
)
st.write(
    "- Use energy-efficient appliances and LED lighting where practical."
)
st.write(
    "- If possible, shift flexible tasks such as laundry to lower-use "
    "hours, while considering your electricity tariff."
)

st.caption(
    "These suggestions are based on limited consumption readings. "
    "The system cannot identify individual appliances from total "
    "electricity readings alone."
)
