
import streamlit as st
import pandas as pd
from pathlib import Path
from datetime import datetime
from io import BytesIO

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
    PageBreak,
)
from reportlab.graphics.shapes import Drawing
from reportlab.graphics.charts.barcharts import VerticalBarChart
from reportlab.graphics.charts.textlabels import Label

st.set_page_config(
    page_title="Electricity Reports",
    page_icon="📄",
    layout="wide"
)

ROOT = Path(__file__).resolve().parents[2]
DATA_PATH = ROOT / "data" / "processed" / "electricity_data.csv"

st.sidebar.title("⚡ Smart Electricity System")
st.sidebar.page_link("app.py", label="Home", icon="🏠")
st.sidebar.page_link(
    "pages/1_Dashboard.py", label="Dashboard", icon="📊"
)
st.sidebar.page_link(
    "pages/2_Data_Management.py", label="Data Management", icon="📁"
)
st.sidebar.page_link(
    "pages/3_Forecasting.py", label="Forecasting", icon="🔮"
)
st.sidebar.page_link(
    "pages/4_Bill_Estimation.py", label="Bill Estimation", icon="💰"
)
st.sidebar.page_link(
    "pages/5_Optimization.py", label="Optimization", icon="⚡"
)
st.sidebar.page_link(
    "pages/6_Reports.py", label="Reports", icon="📄"
)

st.title("📄 Electricity Consumption Reports")
st.write("Generate and download a professional PDF report.")

if not DATA_PATH.exists():
    st.warning("No electricity data found. Upload your CSV first.")
    st.stop()

try:
    df = pd.read_csv(DATA_PATH)

    if not {"timestamp", "consumption_kwh"}.issubset(df.columns):
        st.error(
            "The CSV must contain timestamp and consumption_kwh columns."
        )
        st.stop()

    df["timestamp"] = pd.to_datetime(
        df["timestamp"], errors="coerce"
    )
    df["consumption_kwh"] = pd.to_numeric(
        df["consumption_kwh"], errors="coerce"
    )

    df = df.dropna(
        subset=["timestamp", "consumption_kwh"]
    ).sort_values("timestamp")

    if df.empty:
        st.error("No valid electricity readings were found.")
        st.stop()

    total = df["consumption_kwh"].sum()
    average = df["consumption_kwh"].mean()
    peak = df["consumption_kwh"].max()
    lowest = df["consumption_kwh"].min()

    daily = df.copy()
    daily["Date"] = daily["timestamp"].dt.strftime("%Y-%m-%d")
    daily = (
        daily.groupby("Date", as_index=False)
        .agg(Total_Consumption_kWh=("consumption_kwh", "sum"))
    )

    st.subheader("Consumption Summary")

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total Consumption", f"{total:.2f} kWh")
    c2.metric("Average Reading", f"{average:.2f} kWh")
    c3.metric("Peak Reading", f"{peak:.2f} kWh")
    c4.metric("Valid Readings", len(df))

    st.subheader("Daily Consumption")
    st.dataframe(
        daily.rename(columns={
            "Date": "Date",
            "Total_Consumption_kWh": "Total Consumption (kWh)"
        }),
        use_container_width=True,
        hide_index=True
    )

    def create_pdf():
        buffer = BytesIO()

        document = SimpleDocTemplate(
            buffer,
            pagesize=A4,
            rightMargin=1.7 * cm,
            leftMargin=1.7 * cm,
            topMargin=1.7 * cm,
            bottomMargin=1.7 * cm,
        )

        styles = getSampleStyleSheet()
        styles.add(ParagraphStyle(
            name="ReportTitle",
            parent=styles["Title"],
            alignment=TA_CENTER,
            textColor=colors.HexColor("#176B87"),
            fontSize=20,
            spaceAfter=12,
        ))

        story = []

        story.append(Paragraph(
            "Electricity Consumption Report",
            styles["ReportTitle"]
        ))
        story.append(Paragraph(
            f"Generated on {datetime.now().strftime('%d %B %Y, %H:%M')}",
            styles["Normal"]
        ))
        story.append(Spacer(1, 18))

        story.append(Paragraph("Consumption Overview", styles["Heading2"]))

        summary_data = [
            ["Metric", "Value"],
            ["Total consumption", f"{total:.2f} kWh"],
            ["Average reading", f"{average:.2f} kWh"],
            ["Highest reading", f"{peak:.2f} kWh"],
            ["Lowest reading", f"{lowest:.2f} kWh"],
            ["Number of readings", str(len(df))],
            ["Number of days", str(len(daily))],
            ["First reading", df["timestamp"].min().strftime("%d-%m-%Y %H:%M")],
            ["Last reading", df["timestamp"].max().strftime("%d-%m-%Y %H:%M")],
        ]

        summary_table = Table(
            summary_data,
            colWidths=[7 * cm, 9 * cm],
            repeatRows=1
        )
        summary_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#176B87")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("PADDING", (0, 0), (-1, -1), 7),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1),
             [colors.white, colors.HexColor("#EAF4F4")]),
        ]))

        story.append(summary_table)
        story.append(Spacer(1, 20))
        story.append(Paragraph("Daily Consumption Chart", styles["Heading2"]))

        # Show up to the latest 14 days in the chart.
        chart_data = daily.tail(14)
        drawing = Drawing(470, 250)

        chart = VerticalBarChart()
        chart.x = 48
        chart.y = 45
        chart.width = 390
        chart.height = 175
        chart.data = [
            chart_data["Total_Consumption_kWh"].tolist()
        ]
        chart.categoryAxis.categoryNames = chart_data["Date"].tolist()
        chart.categoryAxis.labels.angle = 35
        chart.categoryAxis.labels.boxAnchor = "ne"
        chart.categoryAxis.labels.fontSize = 7
        chart.valueAxis.valueMin = 0
        chart.valueAxis.labels.fontSize = 8
        chart.barWidth = min(
            20,
            300 / max(len(chart_data), 1)
        )
        chart.groupSpacing = 8

        drawing.add(chart)
        story.append(drawing)
        story.append(Spacer(1, 15))

        story.append(Paragraph("Daily Consumption Details", styles["Heading2"]))

        table_data = [["Date", "Total Consumption (kWh)"]]
        for _, row in daily.iterrows():
            table_data.append([
                row["Date"],
                f"{row['Total_Consumption_kWh']:.2f}"
            ])

        daily_table = Table(
            table_data,
            colWidths=[7 * cm, 9 * cm],
            repeatRows=1
        )
        daily_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#176B87")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("PADDING", (0, 0), (-1, -1), 6),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1),
             [colors.white, colors.HexColor("#EAF4F4")]),
        ]))

        story.append(daily_table)
        story.append(Spacer(1, 18))
        story.append(Paragraph(
            "Note: This report summarizes the uploaded electricity readings. "
            "It does not guarantee future consumption or include official "
            "utility charges.",
            styles["Italic"]
        ))

        def add_page_number(canvas, doc):
            canvas.saveState()
            canvas.setFont("Helvetica", 8)
            canvas.drawCentredString(
                A4[0] / 2,
                0.8 * cm,
                f"Page {doc.page}"
            )
            canvas.restoreState()

        document.build(
            story,
            onFirstPage=add_page_number,
            onLaterPages=add_page_number
        )

        buffer.seek(0)
        return buffer.getvalue()

    st.subheader("Download Your Report")

    if st.button("Generate PDF Report", type="primary"):
        try:
            pdf_bytes = create_pdf()
            st.session_state["electricity_pdf"] = pdf_bytes
            st.success("Your PDF report is ready!")
        except Exception as exc:
            st.error(f"Could not generate the PDF: {exc}")

    if "electricity_pdf" in st.session_state:
        st.download_button(
            "Download PDF Report",
            data=st.session_state["electricity_pdf"],
            file_name="electricity_consumption_report.pdf",
            mime="application/pdf"
        )

    st.download_button(
        "Download Detailed CSV",
        df[["timestamp", "consumption_kwh"]]
        .to_csv(index=False).encode("utf-8"),
        file_name="electricity_readings.csv",
        mime="text/csv"
    )

except Exception as exc:
    st.error(f"Unable to create report: {exc}")
