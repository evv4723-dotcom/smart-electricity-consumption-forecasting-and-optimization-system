
import streamlit as st
import pandas as pd
import plotly.express as px
from pathlib import Path

# --------------------------------------------------
# Page configuration
# --------------------------------------------------
st.set_page_config(
    page_title="Electricity Dashboard",
    page_icon="⚡",
    layout="wide"
)

# --------------------------------------------------
# Project paths
# --------------------------------------------------
ROOT = Path(__file__).resolve().parents[2]
DATA_PATH = ROOT / "data" / "processed" / "electricity_data.csv"

# --------------------------------------------------
# Sidebar navigation
# --------------------------------------------------
st.sidebar.title("⚡ Smart Electricity System")
st.sidebar.caption("Navigate between project features")

st.sidebar.page_link("app.py", label="Home", icon="🏠")
st.sidebar.page_link("pages/1_Dashboard.py", label="Dashboard", icon="📊")
st.sidebar.page_link("pages/2_Data_Management.py", label="Data Management", icon="📁")
st.sidebar.page_link("pages/3_Forecasting.py", label="Forecasting", icon="🔮")
st.sidebar.page_link("pages/4_Bill_Estimation.py", label="Bill Estimation", icon="💰")
st.sidebar.page_link("pages/5_Optimization.py", label="Optimization", icon="⚡")
st.sidebar.page_link("pages/6_Reports.py", label="Reports", icon="📄")

# --------------------------------------------------
# Dashboard heading
# --------------------------------------------------
st.title("⚡ Electricity Consumption Dashboard")
st.write(
    "Monitor consumption, compare usage over time, "
    "and receive alerts for high electricity readings."
)

st.divider()

# --------------------------------------------------
# Load and validate data
# --------------------------------------------------
if not DATA_PATH.exists():
    st.warning("No electricity data found.")
    st.info(
        "Open Data Management and upload a CSV containing "
        "timestamp and consumption_kwh columns."
    )
    st.stop()

try:
    df = pd.read_csv(DATA_PATH)

    required_columns = {"timestamp", "consumption_kwh"}

    if not required_columns.issubset(df.columns):
        st.error(
            "Your CSV must contain 'timestamp' and "
            "'consumption_kwh' columns."
        )
        st.stop()

    df["timestamp"] = pd.to_datetime(
        df["timestamp"], errors="coerce"
    )
    df["consumption_kwh"] = pd.to_numeric(
        df["consumption_kwh"], errors="coerce"
    )

    df = df.dropna(
        subset=["timestamp", "consumption_kwh"]
    ).sort_values("timestamp").copy()

    # Negative consumption values are invalid for this demo.
    df = df[df["consumption_kwh"] >= 0].copy()

    if df.empty:
        st.warning("No valid, non-negative readings were found.")
        st.stop()

    df["date"] = df["timestamp"].dt.normalize()

    latest_date = df["date"].max()
    earliest_date = df["date"].min()

    # --------------------------------------------------
    # Consumption overview
    # --------------------------------------------------
    total_kwh = df["consumption_kwh"].sum()
    average_kwh = df["consumption_kwh"].mean()
    peak_kwh = df["consumption_kwh"].max()
    latest_kwh = df.iloc[-1]["consumption_kwh"]

    st.subheader("Consumption Overview")

    c1, c2, c3, c4 = st.columns(4)

    c1.metric("Total Consumption", f"{total_kwh:.2f} kWh")
    c2.metric("Average Reading", f"{average_kwh:.2f} kWh")
    c3.metric("Peak Reading", f"{peak_kwh:.2f} kWh")
    c4.metric("Valid Readings", f"{len(df):,}")

    st.caption(
        f"Data covers {earliest_date:%d %b %Y} to "
        f"{latest_date:%d %b %Y}."
    )

    st.divider()

    # --------------------------------------------------
    # HIGH CONSUMPTION ALERT SYSTEM
    # --------------------------------------------------
    st.header("🚨 High Electricity Consumption Alerts")

    st.write(
        "Set a consumption limit. Any reading above this limit "
        "will be flagged for review."
    )

    suggested_limit = max(0.1, round(average_kwh * 1.5, 2))

    threshold = st.number_input(
        "Alert limit per reading (kWh)",
        min_value=0.0,
        value=float(suggested_limit),
        step=0.1,
        help=(
            "Choose the maximum expected consumption for one reading. "
            "The default is 1.5 times the average reading in your data."
        )
    )

    # Flag readings above the selected limit.
    df["high_consumption_alert"] = (
        df["consumption_kwh"] > threshold
    )

    alerts = df[df["high_consumption_alert"]].copy()
    alert_count = len(alerts)

    a1, a2, a3 = st.columns(3)

    a1.metric("Alerts Detected", f"{alert_count}")
    a2.metric("Alert Limit", f"{threshold:.2f} kWh")
    a3.metric(
        "Highest Reading",
        f"{peak_kwh:.2f} kWh",
        delta=(
            f"{peak_kwh - threshold:.2f} kWh above limit"
            if peak_kwh > threshold
            else "Within limit"
        ),
        delta_color="inverse"
    )

    if alert_count > 0:
        st.warning(
            f"⚠️ {alert_count} reading(s) exceed your selected "
            f"limit of {threshold:.2f} kWh."
        )

        st.subheader("Readings Requiring Attention")

        alert_display = alerts[
            ["timestamp", "consumption_kwh"]
        ].copy()

        alert_display = alert_display.rename(columns={
            "timestamp": "Date and Time",
            "consumption_kwh": "Consumption (kWh)"
        })

        alert_display["Excess (kWh)"] = (
            alert_display["Consumption (kWh)"] - threshold
        ).round(2)

        st.dataframe(
            alert_display,
            use_container_width=True,
            hide_index=True
        )

        alert_chart = px.bar(
            alerts,
            x="timestamp",
            y="consumption_kwh",
            title="Readings Above the Alert Limit",
            labels={
                "timestamp": "Date and Time",
                "consumption_kwh": "Consumption (kWh)"
            }
        )

        # Display the chosen limit as a reference line.
        alert_chart.add_hline(
            y=threshold,
            line_dash="dash",
            annotation_text="Alert limit"
        )

        st.plotly_chart(
            alert_chart,
            use_container_width=True,
            key="high_consumption_alert_chart"
        )

        st.download_button(
            "Download High-Consumption Alerts (CSV)",
            data=alert_display.to_csv(index=False).encode("utf-8"),
            file_name="high_consumption_alerts.csv",
            mime="text/csv"
        )

        st.info(
            "Review the flagged readings to see whether they reflect "
            "normal high usage, a change in activity, or a possible issue."
        )

    else:
        st.success(
            "No readings exceed your selected consumption limit."
        )

    st.caption(
        "These are threshold-based alerts, not proof of a fault. "
        "Choose a limit appropriate for your reading interval and "
        "normal electricity usage."
    )

    st.divider()

    # --------------------------------------------------
    # Consumption over time
    # --------------------------------------------------
    st.subheader("Electricity Consumption Over Time")

    line_chart = px.line(
        df,
        x="timestamp",
        y="consumption_kwh",
        markers=True,
        title="Consumption by Reading",
        labels={
            "timestamp": "Date and Time",
            "consumption_kwh": "Consumption (kWh)"
        }
    )

    line_chart.update_layout(height=400)

    st.plotly_chart(
        line_chart,
        use_container_width=True,
        key="consumption_over_time"
    )

    # --------------------------------------------------
    # Daily consumption
    # --------------------------------------------------
    st.subheader("Daily Consumption")

    daily = (
        df.groupby("date", as_index=False)
        .agg(total_kwh=("consumption_kwh", "sum"))
        .sort_values("date")
    )

    daily_chart = px.bar(
        daily,
        x="date",
        y="total_kwh",
        text_auto=".2f",
        title="Total Electricity Consumption per Day",
        labels={
            "date": "Date",
            "total_kwh": "Consumption (kWh)"
        }
    )

    daily_chart.update_layout(height=400, showlegend=False)

    st.plotly_chart(
        daily_chart,
        use_container_width=True,
        key="daily_consumption"
    )

    st.divider()

    # --------------------------------------------------
    # Weekly comparison
    # --------------------------------------------------
    st.header("📅 Weekly Consumption Comparison")

    current_week_end = latest_date
    current_week_start = latest_date - pd.Timedelta(days=6)

    previous_week_end = current_week_start - pd.Timedelta(days=1)
    previous_week_start = previous_week_end - pd.Timedelta(days=6)

    current_week_data = df[
        (df["date"] >= current_week_start)
        & (df["date"] <= current_week_end)
    ]

    previous_week_data = df[
        (df["date"] >= previous_week_start)
        & (df["date"] <= previous_week_end)
    ]

    current_week_total = current_week_data["consumption_kwh"].sum()
    previous_week_total = previous_week_data["consumption_kwh"].sum()

    wc1, wc2 = st.columns(2)

    wc1.metric(
        "Latest 7-Day Consumption",
        f"{current_week_total:.2f} kWh"
    )

    if not previous_week_data.empty:
        if previous_week_total > 0:
            change_pct = (
                (current_week_total - previous_week_total)
                / previous_week_total
            ) * 100

            wc2.metric(
                "Previous 7-Day Consumption",
                f"{previous_week_total:.2f} kWh",
                delta=f"{change_pct:+.1f}% vs previous period",
                delta_color="inverse"
            )
        else:
            wc2.metric(
                "Previous 7-Day Consumption",
                f"{previous_week_total:.2f} kWh"
            )
            st.info(
                "The previous period has zero consumption, so a "
                "percentage comparison cannot be calculated."
            )

        if current_week_total > previous_week_total:
            st.warning(
                "Weekly consumption increased compared with "
                "the previous 7-day period."
            )
        elif current_week_total < previous_week_total:
            st.success(
                "Weekly consumption decreased compared with "
                "the previous 7-day period."
            )
        else:
            st.info("Weekly consumption was unchanged.")

    else:
        wc2.metric(
            "Previous 7-Day Consumption",
            "Not available"
        )
        st.info(
            "At least 14 days of readings are needed to compare "
            "two consecutive 7-day periods."
        )

    st.caption(
        f"Latest period: {current_week_start:%d %b %Y} – "
        f"{current_week_end:%d %b %Y}."
    )

    # --------------------------------------------------
    # Monthly comparison
    # --------------------------------------------------
    st.header("🗓️ Monthly Consumption Comparison")

    df["month"] = df["timestamp"].dt.to_period("M")

    monthly = (
        df.groupby("month", as_index=False)
        .agg(total_kwh=("consumption_kwh", "sum"))
        .sort_values("month")
    )

    latest_month = df["month"].max()
    previous_month = latest_month - 1

    latest_month_rows = monthly[monthly["month"] == latest_month]
    previous_month_rows = monthly[monthly["month"] == previous_month]

    latest_month_total = (
        latest_month_rows["total_kwh"].iloc[0]
        if not latest_month_rows.empty else 0
    )

    previous_month_total = (
        previous_month_rows["total_kwh"].iloc[0]
        if not previous_month_rows.empty else 0
    )

    mc1, mc2 = st.columns(2)

    mc1.metric(
        f"{latest_month.strftime('%B %Y')} Consumption",
        f"{latest_month_total:.2f} kWh"
    )

    if not previous_month_rows.empty:
        if previous_month_total > 0:
            monthly_change_pct = (
                (latest_month_total - previous_month_total)
                / previous_month_total
            ) * 100

            mc2.metric(
                f"{previous_month.strftime('%B %Y')} Consumption",
                f"{previous_month_total:.2f} kWh",
                delta=f"{monthly_change_pct:+.1f}% change",
                delta_color="inverse"
            )
        else:
            mc2.metric(
                f"{previous_month.strftime('%B %Y')} Consumption",
                f"{previous_month_total:.2f} kWh"
            )
            st.info(
                "The previous month has zero consumption, so a "
                "percentage comparison cannot be calculated."
            )

        if latest_month_total > previous_month_total:
            st.warning("Monthly consumption increased.")
        elif latest_month_total < previous_month_total:
            st.success("Monthly consumption decreased.")
        else:
            st.info("Monthly consumption was unchanged.")

    else:
        mc2.metric(
            f"{previous_month.strftime('%B %Y')} Consumption",
            "Not available"
        )
        st.info(
            "Upload readings from the previous calendar month "
            "to compare two months."
        )

    st.caption(
        "Monthly totals use the readings available in each month. "
        "A partially covered month is not a full-month estimate."
    )

    monthly_chart_data = monthly.copy()
    monthly_chart_data["Month"] = monthly_chart_data["month"].astype(str)

    monthly_chart = px.bar(
        monthly_chart_data,
        x="Month",
        y="total_kwh",
        text_auto=".2f",
        title="Monthly Electricity Consumption",
        labels={
            "Month": "Month",
            "total_kwh": "Consumption (kWh)"
        }
    )

    monthly_chart.update_layout(height=400, showlegend=False)

    st.plotly_chart(
        monthly_chart,
        use_container_width=True,
        key="monthly_comparison"
    )

    # --------------------------------------------------
    # Recent readings
    # --------------------------------------------------
    st.divider()
    st.subheader("Recent Electricity Readings")

    st.dataframe(
        df[["timestamp", "consumption_kwh"]].tail(10),
        use_container_width=True,
        hide_index=True
    )

except Exception as exc:
    st.error(f"Unable to load dashboard: {exc}")
