# Smart Electricity Consumption Forecasting and Optimization System

A starter application for forecasting electricity consumption, estimating electricity bills, identifying peak usage, and generating energy-saving recommendations.

## Technology stack
- **Frontend:** Streamlit pages and reusable components
- **Backend:** Python modules for preprocessing, forecasting, billing, and optimization
- **Machine Learning:** Scikit-learn Random Forest baseline
- **Database:** SQLite
- **Visualization:** Plotly (add charts to dashboard pages)
- **Model persistence:** Joblib

## Folder layout
- `frontend/` — Streamlit application, pages, UI components, and assets
- `backend/` — data processing, ML training/prediction, services, and database schema
- `data/raw/` — original datasets
- `data/processed/` — cleaned datasets
- `tests/` — basic unit tests
- `requirements.txt` — Python dependencies

## Setup
Use Python 3.10 or newer.

```bash
python -m venv .venv
```

Activate the environment:
- Windows: `.venv\\Scripts\\activate`
- macOS/Linux: `source .venv/bin/activate`

Install packages:

```bash
pip install -r requirements.txt
```

Run the app from the project root:

```bash
streamlit run frontend/app.py
```

## Dataset format
Place a CSV at `data/raw/electricity_data.csv` with at least:
- `timestamp` — date/time of the reading
- `consumption_kwh` — energy consumed during the interval in kWh

Example:

```csv
timestamp,consumption_kwh
2026-10-01 08:00:00,0.8
2026-10-01 09:00:00,1.2
2026-10-01 10:00:00,0.6
```

Keep readings in consistent intervals. If the source contains cumulative meter readings, convert them into interval consumption before training.

## Train the baseline model

```bash
python -m backend.ml.train_model
```

The training script reports MAE and RMSE and saves a model under `backend/ml/`. The current baseline uses calendar features only; for stronger forecasts, add lag/rolling features and compare against a naive baseline using chronological validation.

## Database
SQLite is initialized when the Streamlit app starts. The schema is in `backend/database/schema.sql`. The schema is a starting point; user authentication and per-user data filtering must be implemented before multi-user deployment.

## Tests

```bash
pytest
```

## Important limitations
- This is a starter scaffold, not a production-ready application.
- Bill calculation currently uses a simple per-kWh rate plus fixed charge. Add local tariff slabs, taxes, and other applicable charges for accurate estimates.
- Optimization currently gives rule-based suggestions; it does not automatically control appliances.
- Forecast quality depends on data coverage, sampling interval, feature engineering, and validation.
