PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE,
    password_hash TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS energy_readings (
    reading_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    timestamp TEXT NOT NULL,
    consumption_kwh REAL NOT NULL CHECK (consumption_kwh >= 0),
    temperature REAL,
    humidity REAL,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    UNIQUE (user_id, timestamp)
);

CREATE TABLE IF NOT EXISTS tariffs (
    tariff_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    rate_per_kwh REAL NOT NULL CHECK (rate_per_kwh >= 0),
    fixed_charge REAL NOT NULL DEFAULT 0 CHECK (fixed_charge >= 0),
    effective_from TEXT,
    effective_to TEXT,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS predictions (
    prediction_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    forecast_time TEXT NOT NULL,
    predicted_kwh REAL NOT NULL CHECK (predicted_kwh >= 0),
    model_name TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS recommendations (
    recommendation_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    message TEXT NOT NULL,
    estimated_savings REAL,
    status TEXT NOT NULL DEFAULT 'new',
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS alerts (
    alert_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    timestamp TEXT NOT NULL,
    alert_type TEXT NOT NULL,
    description TEXT NOT NULL,
    acknowledged INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE INDEX IF NOT EXISTS idx_energy_readings_timestamp
ON energy_readings(timestamp);

CREATE INDEX IF NOT EXISTS idx_predictions_forecast_time
ON predictions(forecast_time);
