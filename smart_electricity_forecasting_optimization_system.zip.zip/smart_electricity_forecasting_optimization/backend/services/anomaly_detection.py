"""Simple statistical spike detection baseline."""

import pandas as pd


def flag_spikes(consumption: pd.Series, z_threshold: float = 3.0) -> pd.Series:
    std = consumption.std(ddof=0)
    if pd.isna(std) or std == 0:
        return pd.Series(False, index=consumption.index)
    return ((consumption - consumption.mean()).abs() / std) > z_threshold
