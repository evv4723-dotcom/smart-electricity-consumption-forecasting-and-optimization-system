"""Starter rule-based recommendations."""


def generate_recommendations(peak_detected=False, above_budget=False):
    recommendations = []
    if peak_detected:
        recommendations.append(
            "Review flexible appliance usage during peak periods where practical."
        )
    if above_budget:
        recommendations.append(
            "Review discretionary usage and compare your forecast against the budget."
        )
    if not recommendations:
        recommendations.append(
            "Continue monitoring consumption; recommendations improve with more data."
        )
    return recommendations
