"""Simple tariff-based bill estimate."""


def estimate_bill(consumption_kwh: float, rate_per_kwh: float, fixed_charge: float = 0.0) -> float:
    if min(consumption_kwh, rate_per_kwh, fixed_charge) < 0:
        raise ValueError("Consumption, rate, and fixed charge must be non-negative.")
    return consumption_kwh * rate_per_kwh + fixed_charge
