"""Time features for baseline forecasting models."""

import pandas as pd


def add_time_features(df: pd.DataFrame) -> pd.DataFrame:
    result = df.copy()
    timestamp = pd.to_datetime(result["timestamp"])
    result["hour"] = timestamp.dt.hour
    result["day_of_week"] = timestamp.dt.dayofweek
    result["month"] = timestamp.dt.month
    result["day_of_year"] = timestamp.dt.dayofyear
    return result
