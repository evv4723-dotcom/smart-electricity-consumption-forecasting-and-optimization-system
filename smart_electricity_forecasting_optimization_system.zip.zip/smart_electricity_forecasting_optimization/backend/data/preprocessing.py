"""Validation and cleaning helpers for electricity datasets."""

import pandas as pd

REQUIRED_COLUMNS = {"timestamp", "consumption_kwh"}


def validate_readings(df: pd.DataFrame) -> pd.DataFrame:
    missing = REQUIRED_COLUMNS - set(df.columns)
    if missing:
        raise ValueError(
            "Missing required column(s): " + ", ".join(sorted(missing))
        )

    cleaned = df.copy()
    cleaned["timestamp"] = pd.to_datetime(cleaned["timestamp"], errors="coerce")
    cleaned["consumption_kwh"] = pd.to_numeric(
        cleaned["consumption_kwh"], errors="coerce"
    )
    cleaned = cleaned.dropna(subset=["timestamp", "consumption_kwh"])
    cleaned = cleaned[cleaned["consumption_kwh"] >= 0]
    cleaned = cleaned.drop_duplicates(subset=["timestamp"])
    return cleaned.sort_values("timestamp").reset_index(drop=True)
