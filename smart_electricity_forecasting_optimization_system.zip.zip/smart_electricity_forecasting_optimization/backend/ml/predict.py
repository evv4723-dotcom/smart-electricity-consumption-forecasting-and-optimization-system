"""Load the trained model and predict consumption for supplied timestamps."""

from pathlib import Path
import joblib
import pandas as pd
from backend.data.features import add_time_features

ROOT = Path(__file__).resolve().parents[2]
MODEL_PATH = ROOT / "backend" / "ml" / "saved_model.joblib"


def predict_timestamps(timestamps):
    if not MODEL_PATH.exists():
        raise FileNotFoundError("Trained model not found. Run python -m backend.ml.train_model first.")
    bundle = joblib.load(MODEL_PATH)
    frame = pd.DataFrame({"timestamp": pd.to_datetime(timestamps)})
    frame = add_time_features(frame)
    predictions = bundle["model"].predict(frame[bundle["features"]])
    return [max(0.0, float(value)) for value in predictions]
