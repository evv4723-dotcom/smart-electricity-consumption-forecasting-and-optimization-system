"""Train a baseline Random Forest model using chronological holdout data."""

from pathlib import Path
import joblib
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error

from backend.data.preprocessing import validate_readings
from backend.data.features import add_time_features

ROOT = Path(__file__).resolve().parents[1].parent
DATA_PATH = ROOT / "data" / "raw" / "electricity_data.csv"
MODEL_PATH = ROOT / "backend" / "ml" / "saved_model.joblib"
FEATURES = ["hour", "day_of_week", "month", "day_of_year"]


def main():
    if not DATA_PATH.exists():
        raise FileNotFoundError(
            f"Place a dataset at {DATA_PATH} with timestamp and consumption_kwh columns."
        )

    df = validate_readings(pd.read_csv(DATA_PATH))
    df = add_time_features(df)

    split = int(len(df) * 0.8)
    if split < 10 or len(df) - split < 2:
        raise ValueError("Not enough data for a chronological train/test split.")

    X_train, X_test = df[FEATURES].iloc[:split], df[FEATURES].iloc[split:]
    y_train, y_test = df["consumption_kwh"].iloc[:split], df["consumption_kwh"].iloc[split:]

    model = RandomForestRegressor(n_estimators=200, random_state=42)
    model.fit(X_train, y_train)
    predicted = model.predict(X_test)

    print(f"MAE: {mean_absolute_error(y_test, predicted):.4f} kWh")
    print(f"RMSE: {mean_squared_error(y_test, predicted) ** 0.5:.4f} kWh")

    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump({"model": model, "features": FEATURES}, MODEL_PATH)
    print(f"Saved model to {MODEL_PATH}")


if __name__ == "__main__":
    main()
