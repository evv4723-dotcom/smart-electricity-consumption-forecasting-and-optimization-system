from backend.services.billing import estimate_bill


def test_estimate_bill():
    assert estimate_bill(10, 5, 20) == 70
