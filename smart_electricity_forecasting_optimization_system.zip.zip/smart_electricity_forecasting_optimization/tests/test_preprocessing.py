import pandas as pd
from backend.data.preprocessing import validate_readings


def test_validation_drops_invalid_rows():
    df = pd.DataFrame({
        "timestamp": ["2026-01-01 08:00", "not-a-date"],
        "consumption_kwh": [1.5, 2.0],
    })
    result = validate_readings(df)
    assert len(result) == 1
    assert result.iloc[0]["consumption_kwh"] == 1.5
